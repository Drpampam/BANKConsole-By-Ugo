﻿using UGBANKS.Auth;
using UGBANKS.UI;

//Authentication.register();
HomePage.main();